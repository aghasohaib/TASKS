#include <iostream>
using namespace std;

int main() {
    int initialBalance = 1000, amount, choice, pin = 1234, enteredPin, balance = initialBalance;

    do {
        cout << "\nBank Account Management System" << endl;
        cout << "1. Deposit Money" << endl;
        cout << "2. Withdraw Money" << endl;
        cout << "3. Check Balance" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: // Deposit Money
                cout << "Enter Amount to Deposit: ";
                cin >> amount;
                if (amount > 0) {
                    balance += amount;
                    cout << "Deposited successfully. Current balance: " << balance << endl;
                } else {
                    cout << "Invalid amount. Enter a positive value." << endl;
                }
                break;

            case 2: // Withdraw Money
                cout << "Enter the PIN code: ";
                cin >> enteredPin;
                if (enteredPin == pin) {
                    cout << "Enter Withdrawal Amount: ";
                    cin >> amount;
                    if (amount > 0 && amount <= balance) {
                        balance -= amount;
                        cout << "Withdrawn successfully. Current balance: " << balance << endl;
                    } else if (amount > balance) {
                        cout << "Insufficient balance." << endl;
                    } else {
                        cout << "Invalid amount. Enter a positive value." << endl;
                    }
                } else {
                    cout << "Incorrect PIN." << endl;
                }
                break;

            case 3: // Check Balance
                cout << "Enter the PIN code: ";
                cin >> enteredPin;
                if (enteredPin == pin) {
                    cout << "Your current balance is: " << balance << endl;
                } else {
                    cout << "Incorrect PIN." << endl;
                }
                break;

            case 4: // Exit
                cout << "Exiting the system. Thank you!" << endl;
                break;

            default:
                cout << "Invalid option. Please try again." << endl;
                break;
        }
    } while (choice != 4);

    return 0;
}