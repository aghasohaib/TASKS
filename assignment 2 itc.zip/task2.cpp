#include <iostream>
using namespace std;
int main()
{
	// variables to check availablity and borrowing of books
    int book1Available = 3;
    int book1Borrowed = 0;
    int book2Available = 2;
    int book2Borrowed = 0;
    int book3Available = 1; int book3Borrowed = 0;
    int book4Available = 0; int book4Borrowed = 0;
    int book5Available = 5; int book5Borrowed = 0;
	int choice;
	int bookChoice;
	do {
		// display the menu
		cout << " Library Book Borrowing System " << endl;
		cout << "1. Borrow a Book" << endl;
		cout << "2. Return a Book" << endl;
		cout << "3. EXIT" << endl;
		cout << "Enter your choice" << endl;
		cin >> choice;
		switch (choice) {
		case 1: { // borrow book
			cout << "Available books:" << endl;
			cout << "1. Book 1 (The Catcher in the Rye) - Available: " << book1Available << endl;
			cout << "2. Book 2 (1984) - Available: " << book2Available << endl;
			cout << "3. Book 3 (To Kill a Mockingbird) - Available: " << book3Available << endl;
			cout << "4. Book 4 (The Great Gatsby) - Available: " << book4Available << endl;
			cout << "5. Book 5 (Moby Dick) - Available: " << book5Available << endl;
			cout << "Enter the number of the book you want to borrow: " << endl;
			cin >> bookChoice;
            if (bookChoice == 1) {
                if (book1Available == 0) {
                    cout << "Sorry, Book 1 is not available." << endl;
                }
                else if (book1Borrowed == 1) {
                    cout << "You have already borrowed Book 1." << endl;
                }
                else {
                    book1Available--;
                    book1Borrowed = 1;
                    cout << "You have successfully borrowed Book 1." << endl;
                }
            }
            else if (bookChoice == 2) {
                if (book2Available == 0) {
                    cout << "Sorry, Book 2 is not available." << endl;
                }
                else if (book2Borrowed == 1) {
                    cout << "You have already borrowed Book 2." << endl;
                }
                else {
                    book2Available--;
                    book2Borrowed = 1;
                    cout << "You have successfully borrowed Book 2." << endl;
                }
            }
            else if (bookChoice == 3) {
                if (book3Available == 0) {
                    cout << "Sorry, Book 3 is not available." << endl;
                }
                else if (book3Borrowed == 1) {
                    cout << "You have already borrowed Book 3." << endl;
                }
                else {
                    book3Available--;
                    book3Borrowed = 1;
                    cout << "You have successfully borrowed Book 3." << endl;
                }
            }
            else if (bookChoice == 4) {
                if (book4Available == 0) {
                    cout << "Sorry, Book 4 is not available." << endl;
                }
                else if ( book4Borrowed == 1) {
                    cout << "You have already borrowed Book 4." << endl;
                }
                else {
                    book4Available--;
                    book4Borrowed = 1;
                    cout << "You have successfully borrowed Book 4." << endl;
                }
            }
            else if (bookChoice == 5) {
                if (book5Available == 0) {
                    cout << "Sorry, Book 5 is not available." << endl;
                }
                else if ( book5Borrowed == 1) {
                    cout << "You have already borrowed Book 5." << endl;
                }
                else {
                    book5Available--;
                    book5Borrowed = 1;
                    cout << "You have successfully borrowed Book 5." << endl;
                }
            }
            else {
                cout << "Invalid book selection. Please try again." << endl;
            }
            break;
        }
        case 2: { // Return a book
            cout << "\nBooks You Have Borrowed:" << endl;
            if (book1Borrowed) cout << "1. Book 1" << endl;
            if (book2Borrowed) cout << "2. Book 2" << endl;
            if (book3Borrowed) cout << "3. Book 3" << endl;
            if (book4Borrowed) cout << "4. Book 4" << endl;
            if (book5Borrowed) cout << "5. Book 5" << endl;

            int bookChoice;
            cout << "Enter the number of the book you want to return: ";
            cin >> bookChoice;

            if (bookChoice == 1 && book1Borrowed == 1) {
                book1Available++;
                book1Borrowed = 0;
                cout << "You have successfully returned Book 1." << endl;
            }
            else if (bookChoice == 2 && book2Borrowed == 1) {
                book2Available++;
                book2Borrowed = 0;
                cout << "You have successfully returned Book 2." << endl;
            }
            else if (bookChoice == 3 && book3Borrowed == 1) {
                book3Available++;
                book3Borrowed = 0;
                cout << "You have successfully returned Book 3." << endl;
            }
            else if (bookChoice == 4 && book4Borrowed == 1) {
                book4Available++;
                book4Borrowed = 0;
                cout << "You have successfully returned Book 4." << endl;
            }
            else if (bookChoice == 5 && book5Borrowed == 1) {
                book5Available++;
                book5Borrowed = 0;
                cout << "You have successfully returned Book 5." << endl;
            }
            else {
                cout << "Invalid selection or you have not borrowed this book." << endl;
            }
            break;
        }
        case 3: {
            cout << "Exiting the system. Thank you!" << endl;
            break;
        }

        default: {
            cout << "Invalid option. Please try again." << endl;
            break;
        }
        }
    } while (choice != 3);

    return 0;
}
