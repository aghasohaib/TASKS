#include <iostream>
using namespace std;

int main() {
    // Pattern 1
    int i = 1;
    while (i <= 5) { // loop for rows
        int j = 1;
        while (j <= i) { // loop for numbers in each row
            cout << j << " "; // print numbers with spaces
            j++; // increment j inside the inner loop
        }
        cout << endl; // move to the next line after each row
        i++; // increment i for the next row
    }

    cout << endl; // ADD empty line between both patterns

    // Pattern 2
    i = 1;
    while (i <= 5) { // loop for rows
        int j = 1;
        while (j <= i) { // loop for stars in each row
            cout << "*";
            j++;
        }
        cout << endl; // move to next line after each row
        i++;
    }
    return 0;
}
